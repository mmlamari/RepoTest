﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace CME_VendingMachineCalculator
{

    /// <summary>
    /// Vending Machine Engine
    /// </summary>
    public class VendingMachine
    {
      
        /// <summary>
        ///Accessor to products
        /// </summary>
        private Iproducts _p;

        /// <summary>
        ///Product selected by customer
        /// </summary>
        private ProductDescription _productDescription = new ProductDescription();

        private Dictionary<int,int> _changeavailable = new Dictionary<int, int>();


        private Dictionary<string, int> _accptedbills = new Dictionary<string, int>();

        private int _changedue;

        /// <summary>
        ///init machine with  some kind of product(productsdrinks,productsCandies....) 
        /// </summary>
        public VendingMachine(Iproducts p)
        {
            _p = p;
            _changeavailable.Add((int)CoinsType.dollar, 0);
            _changeavailable.Add((int)CoinsType.cents ,100);
            _changeavailable.Add((int)CoinsType.cents5 ,50 );
            _changeavailable.Add((int)CoinsType.cents10 ,50 );
            _changeavailable.Add((int)CoinsType.cents25 ,50 );

            
            _accptedbills.Add("1d", (int)CoinsType.dollar);
            _accptedbills.Add("25c", (int)CoinsType.cents25);
            _accptedbills.Add("10c", (int)CoinsType.cents10);
            _accptedbills.Add("5c", (int)CoinsType.cents5);
            _accptedbills.Add("1c", (int)CoinsType.cents);
         
        }
        /// <summary>
        ///LoadVendingMachine with product for sell
        /// </summary>
        public List<ProductDescription>  LoadVendingMachine(){

            return _p.GeProducts();
        }

        /// <summary>
        ///Get Product price
        /// </summary>
        public int GetProduct(int productid)
        {
            var price = -1;

            _productDescription = _p.GetProduct(productid);

            if (_productDescription != null)
            {
                price = _productDescription._pprice;
            }

            return price;
        }
        /// <summary>
        ///Calculate Change
        /// </summary>
        public string Calculatechange(double depositedamoun) 
        {
            var change = (depositedamoun - _productDescription._pprice) / 100;

            return "";

        }

        public Dictionary<string, int> AccpetedBills()
        {
            return _accptedbills;
        }
        public void Addtomychange(string entredamount)
        {

            _changeavailable[_accptedbills[entredamount]] += 1;


        }
        public string SubstructFromchange(int change)
        {

            var cents25 = change / 25;
            var cents10 = (change - cents25 * 25) / 10;
            var cents5 = (change - cents25*25 - cents10*10) / 5;
            var cents1 = (change - cents25*25 - cents10*10 - cents5*5);

            if ((_changeavailable.Sum(x => x.Value * x.Key) -
                 _changeavailable[(int) CoinsType.dollar] * (int) CoinsType.dollar) >= change)
            {
               
               
                _changeavailable[(int) CoinsType.cents25] -= cents25;
                _changeavailable[(int) CoinsType.cents10] -= cents10;
                _changeavailable[(int) CoinsType.cents5] -= cents5;
                _changeavailable[(int) CoinsType.cents] -= cents1;

                return String.Format("{0} * 25c ,{1} * 10c ,{2} * 5c,{3} * 1c", cents25, cents10, cents5, cents1);
            }

            return changevailable.no.ToString();


        }

      

        //public int getchangeback()

    }
    public class ProductDescription
    {
        public int _pprice;
        public string _pproductDescription;
        public int _productid;

    }



    public class productsdrinks : Iproducts
    {
        private List<ProductDescription> _lstproducts= new List<ProductDescription>();

        public productsdrinks()
        {

           SetProducts();
        }

        public List<ProductDescription> GeProducts(){
           
            return _lstproducts;
        }

        public ProductDescription GetProduct(int productid )
        {
        
            
            if(_lstproducts.Where(s => s._productid == productid).Count() ==1)

                return _lstproducts.Where(s => s._productid == productid).FirstOrDefault();

            return null;

        }

        public void  SetProducts()
        {
            //Price in cents
            _lstproducts.Add(new ProductDescription { _pproductDescription = "Coke", _pprice =  120, _productid = 1 });
            _lstproducts.Add(new ProductDescription { _pproductDescription = "Pepsi", _pprice =  100, _productid = 2 });
            _lstproducts.Add(new ProductDescription { _pproductDescription = "Water", _pprice =  130, _productid = 3 });
            _lstproducts.Add(new ProductDescription { _pproductDescription = "Snikers", _pprice = 75, _productid = 4 });
            _lstproducts.Add(new ProductDescription { _pproductDescription = "Sprite", _pprice =  290, _productid = 5 });
            _lstproducts.Add(new ProductDescription { _pproductDescription = "Hurchies", _pprice = 300, _productid = 6 });

            

        }

       
    }

    public enum CoinsType
    {
        dollar = 100,
        cents =1,
        cents5 =5,
        cents10 =10,
        cents25 =25

    }

    public enum changevailable //shared component
    {
        
        no = 0

    }
}
