﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace CME_VendingMachineCalculator
{
    class Program
    {
        public static bool customersbuying = true;
        static void Main(string[] args)
        {

            var vm = new VendingMachine(new productsdrinks()); //Day start, Program started
            while (customersbuying)
            {
                var depositedcoins = new List<string>();
                var productid = 0;
                var productprice = 0;
                var billsaccepted = new Dictionary<string, int>();
                var depositedamount = 0;
                var refund = 0;

                var listofproducts = vm.LoadVendingMachine(); //Load machine with products

                Console.WriteLine("Product Number / Product Name / Price ($)");
                foreach (var p in listofproducts)
                {
                    Console.WriteLine("{0} / {1}  / {2}",
                        p._productid, p._pproductDescription, ConvertTocents(p._pprice));
                }

                Console.WriteLine("Please Enter product number ...");


        
                if (!int.TryParse(Console.ReadLine(), out productid) //not a number
                    || (listofproducts.Where(p => p._productid == productid).Count() == 0))  //Product does not exist
                {
                    Console.WriteLine("Please Enter product number...");
                }
                else //Get Product Price 
                {
                    productprice = vm.GetProduct(productid);
                    billsaccepted = vm.AccpetedBills();

                    Console.WriteLine("Please Pay {0}: ", ConvertTocents(productprice));

                    foreach (var bills in billsaccepted)
                    {
                        Console.WriteLine("Please Enter: {0} for {1} cents ", bills.Key, bills.Value);
                    }


                }
                
                while (depositedamount < productprice)
                {
                    var entredamount = Console.ReadLine();

                    if (entredamount.ToLower() == "exit")
                    {

                        if (depositedamount > 0)
                            Console.WriteLine("Please get  your refund ", depositedamount);

                        break;

                    }
                    if (!billsaccepted.ContainsKey(entredamount))
                    {

                        foreach (var bills in billsaccepted)
                        {
                            Console.WriteLine("Please Enter: {0} for {1} cents  ", bills.Key, bills.Value);
                        }

                        Console.WriteLine("Please Pay {0}: or type exit to get your refund if any ",ConvertTocents(productprice));
                        // 

                    }
                    else
                    {
                        depositedamount += billsaccepted[entredamount];

                        depositedcoins.Add(entredamount);
                      

                    }

                    if (depositedamount >= productprice)
                    {
                        var change = depositedamount - productprice;
                        var changeavailable = vm.SubstructFromchange(change);

                        if (changeavailable != changevailable.no.ToString())
                        {

                            var productdescription = listofproducts.Where(p => p._productid == productid)
                                .Select(s => s._pproductDescription).FirstOrDefault();
                            Console.WriteLine("Please get your: {0}", productdescription);

                            foreach (var dep in depositedcoins)
                            {
                                vm.Addtomychange(dep);
                            }
                            if (change > 0)
                            {
                                Console.WriteLine("Change due to customer: {0} ", changeavailable);

                            }
                        }
                        else
                        {

                            Console.WriteLine("Sorry no change availablle" );
                        }

                        


                        break;
                    }
                    else
                    {
                        var remainingbalnce = -1 * (depositedamount - productprice);
                        Console.WriteLine("remaining balance {0} cents", remainingbalnce);
                    }


                }

                Console.WriteLine("Have a good day.");
                Console.WriteLine("Please enter 1 to buy another product, or press any key to exit");
                var exit = Console.ReadLine();
                if(exit != "1") customersbuying = false;
            }

            return;

        }

        static string ConvertTocents(int price) //Client should take care of how the price needs to be displayed
        {
            var pricestring = "$" + ((int) (price / 100)).ToString() + "." + ((int)(price % 100)).ToString(); //Use string.format

            return pricestring;



        }
    }
}
