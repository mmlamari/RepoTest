﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Text;

namespace CME_VendingMachineCalculator
{
    public interface Iproducts
    {

        void SetProducts();
        List<ProductDescription> GeProducts();

        ProductDescription GetProduct(int productid);
    }
}
